plugins {
    kotlin("jvm") version "1.8.10"
    id("idea")
    id("java")
    id("org.jetbrains.intellij") version "1.15.0"
}

group = "com.alibaba"
version = "1.0"

repositories {
    maven { setUrl("https://maven.aliyun.com/repository/public/") }
    maven { setUrl("https://maven.aliyun.com/repository/spring/")}
    maven { setUrl("https://maven.aliyun.com/repository/google/")}
    maven { setUrl("https://maven.aliyun.com/repository/gradle-plugin/")}
    maven { setUrl("https://maven.aliyun.com/repository/spring-plugin/")}
    maven { setUrl("https://maven.aliyun.com/repository/grails-core/")}
    maven { setUrl("https://maven.aliyun.com/repository/apache-snapshots/")}
    mavenCentral()
}

buildscript {
    repositories {
        maven { setUrl("https://maven.aliyun.com/repository/public/") }
        maven { setUrl("https://maven.aliyun.com/repository/spring/")}
        maven { setUrl("https://maven.aliyun.com/repository/google/")}
        maven { setUrl("https://maven.aliyun.com/repository/gradle-plugin/")}
        maven { setUrl("https://maven.aliyun.com/repository/spring-plugin/")}
        maven { setUrl("https://maven.aliyun.com/repository/grails-core/")}
        maven { setUrl("https://maven.aliyun.com/repository/apache-snapshots/")}
        mavenCentral()
    }
    dependencies {
        "classpath"(group = "org.jetbrains.intellij", name = "blockmap", version = "1.0.6")
    }
}

// Configure Gradle IntelliJ Plugin
// Read more: https://plugins.jetbrains.com/docs/intellij/tools-gradle-intellij-plugin.html
intellij {
    version.set("2022.3.1")
    type.set("IC") // Target IDE Platform
    pluginName.set("p3c-common")
    plugins.set(listOf("Git4Idea","java"))
}

dependencies {
    implementation("com.alibaba.p3c:p3c-pmd:2.1.0")
    implementation("org.freemarker:freemarker:2.3.25-incubating")
    implementation("org.javassist:javassist:3.21.0-GA")
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

tasks {
    // Set the JVM compatibility versions
    withType<JavaCompile> {
        sourceCompatibility = "11"
        targetCompatibility = "11"
    }
    withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
        kotlinOptions.jvmTarget = "11"
    }

    fun copyPlugins(destinationDir: File, pluginName: Property<String>) {
        copy {
            //from(project.configurations["sqplugins"])
            into(file("$destinationDir/${pluginName.get()}/plugins"))
        }
    }

    prepareSandbox {
        //dependsOn(downloadOmnisharpMonoZipFile, downloadOmnisharpWinZipFile, downloadOmnisharpNet6ZipFile)
        doLast {
            copyPlugins(destinationDir, pluginName)
            // copyOmnisharp(destinationDir, pluginName)
        }
    }

    patchPluginXml {
        //sinceBuild.set("213")
        //untilBuild.set("223.*")
    }

    signPlugin {
        certificateChain.set(System.getenv("CERTIFICATE_CHAIN"))
        privateKey.set(System.getenv("PRIVATE_KEY"))
        password.set(System.getenv("PRIVATE_KEY_PASSWORD"))
    }

    publishPlugin {
        token.set(System.getenv("PUBLISH_TOKEN"))
    }
}

tasks.runIde {
    //systemProperty("sonarlint.telemetry.disabled", "true")
    // uncomment to customize the SonarCloud URL
    //systemProperty("sonarlint.internal.sonarcloud.url", "https://sonarcloud.io/")
//    if (project.hasProperty("runIdeDirectory")) {
//        ideDir.set(File(runIdeDirectory))
//    }
    maxHeapSize = "2g"
}
